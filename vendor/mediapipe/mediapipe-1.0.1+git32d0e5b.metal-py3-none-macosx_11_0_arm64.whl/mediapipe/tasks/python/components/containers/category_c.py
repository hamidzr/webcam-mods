# Copyright 2025 The MediaPipe Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""C types for MpCategory."""

import ctypes


class MpCategoryC(ctypes.Structure):
  """The ctypes struct for MpCategory."""

  _fields_ = [
      ("index", ctypes.c_int),
      ("score", ctypes.c_float),
      ("category_name", ctypes.c_char_p),
      ("display_name", ctypes.c_char_p),
  ]


class MpCategoriesC(ctypes.Structure):
  """C types for a list of MpCategories."""

  _fields_ = [
      ("categories", ctypes.POINTER(MpCategoryC)),
      ("categories_count", ctypes.c_uint32),
  ]
